This are example scripts for using lolMiner with activation of 
the compute mode. To use them the please copy this into the root 
folder of the miner and execute them.

Note that the miner needs to restart the display driver to apply
the new settings. This may take a moment and also may give a 
flickering screen and or artifacts during the restart process. 

In case of crash reboot the rig and start the example files 
without the compute mode switch.
